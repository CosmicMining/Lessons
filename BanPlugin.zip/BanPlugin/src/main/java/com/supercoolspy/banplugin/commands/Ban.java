package com.supercoolspy.banplugin.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Ban implements CommandExecutor {

    //make a command that bans a player
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        //kick the player that is args[0]
        if(sender.hasPermission("banplugin.ban")) {
            if(sender instanceof Player) {
                if(args.length == 1) {
                    //set args[0] to the player that is being banned if they exist
                    Player target = sender.getServer().getPlayer(args[0]);
                    //if the player exists
                    if(target != null) {
                        //kick the player
                        target.kickPlayer("You have been banned from the server.");
                    }
                }
            }
        }
        return true;
    }
}
