package com.supercoolspy.banplugin.Listeners;

import com.supercoolspy.banplugin.Banplugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.util.ArrayList;
import java.util.Objects;

public class onPlayerAdded implements Listener {
    Banplugin plugin = new Banplugin();
    @EventHandler
    public void playerJoinEvent(PlayerJoinEvent event) {
        //Kick the player if they are in the banned IP array
        if (plugin.getConfig().getStringList("bannedIPs").contains(Objects.requireNonNull(event.getPlayer().getAddress()).getHostString())) {
            //get the reason for the ban
            String reason = plugin.getConfig().getString("bannedIPs." + event.getPlayer().getAddress().getHostString() + ".reason");
            //get the time of the ban
            String time = plugin.getConfig().getString("bannedIPs." + event.getPlayer().getAddress().getHostString() + ".time");
            //kick the player for the reason and time
            event.getPlayer().kickPlayer("You have been banned for " + reason + " for " + time + "!");
        }
        //Kick the player if they are in the banned UUID array
        if (plugin.getConfig().getStringList("bannedUUIDs").contains(event.getPlayer().getUniqueId().toString())) {
            //get the reason for the ban
            String reason = plugin.getConfig().getString("bannedUUIDs." + event.getPlayer().getUniqueId().toString() + ".reason");
            //get the time of the ban
            String time = plugin.getConfig().getString("bannedUUIDs." + event.getPlayer().getUniqueId().toString() + ".time");
            //kick the player for the reason and time
            event.getPlayer().kickPlayer("You have been banned for " + reason + " for " + time + "!");
        }
    }
}
