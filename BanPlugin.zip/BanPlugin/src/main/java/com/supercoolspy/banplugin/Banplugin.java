package com.supercoolspy.banplugin;

import com.supercoolspy.banplugin.Listeners.onPlayerAdded;
import com.supercoolspy.banplugin.commands.Ban;
import org.bukkit.plugin.java.JavaPlugin;

public final class Banplugin extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic
        //register onPlayerAdded as a listener
        //register the command /ban
        this.getCommand("ban").setExecutor(new Ban());//add baned players to the config
        getConfig().addDefault("bannedUUIDs", "");
        //add banned ips to the config
        getConfig().addDefault("banedIPs", "");
        getConfig().options().copyDefaults(true);
        saveConfig();
        saveDefaultConfig();
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
        //set the console color to red
        System.out.println("\033[0;31m");
        //print the message
        System.out.println("Banplugin is now disabled");
        //set the console color back to white
        System.out.println("\033[0;37m");
    }
}
