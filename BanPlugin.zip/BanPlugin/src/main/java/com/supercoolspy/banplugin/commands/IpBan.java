package com.supercoolspy.banplugin.commands;

public class IpBan {
}
